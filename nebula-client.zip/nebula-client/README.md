# Nebula Client (Fabric 1.21.11)

Karanlık temalı, modüler client-side Fabric modu.

## Derleme

Gereksinimler: JDK 21, internet bağlantısı (Gradle ilk seferde Minecraft ve Fabric bağımlılıklarını indirir).

```bash
# Windows
gradlew.bat build

# Linux / macOS
./gradlew build
```

`gradlew` dosyaları yoksa, Gradle 9.2+ kuruluyken proje klasöründe bir kez `gradle wrapper` çalıştırın.

Çıktı: `build/libs/nebula-client-1.0.0.jar`
(`-sources.jar` ve `-dev.jar` dosyalarını kullanmayın.)

## Kurulum

1. Fabric Loader (1.21.11) ve **Fabric API** kurulu olmalı.
2. `nebula-client-1.0.0.jar` dosyasını `.minecraft/mods` klasörüne atın.

## Kullanım

- **Sağ Shift**: menüyü aç / kapat
- Sol tık: modülü aç/kapat · Sağ tık: modülün ayarlarını aç/kapat
- Panel başlığını sürükleyerek taşıyın; sağ tıkla daraltın
- Ayarlar `config/nebula.json` içine otomatik kaydedilir

## Yeni modül eklemek

`dev.nebula.module.impl` altında `Module`'ü genişleten bir sınıf yazın,
`ModuleManager.init()` içinde `register(new BenimModulum());` ekleyin.
Ayarlar için `add(new BooleanSetting(...))`, `add(new NumberSetting(...))`, `add(new ModeSetting(...))`.
