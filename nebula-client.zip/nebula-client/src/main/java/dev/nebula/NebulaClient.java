package dev.nebula;

import dev.nebula.config.ConfigManager;
import dev.nebula.gui.ClickGuiScreen;
import dev.nebula.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class NebulaClient implements ClientModInitializer {
    public static final String MOD_ID = "nebula";
    public static final String NAME = "Nebula";
    public static final String VERSION = "1.0";
    public static final int ACCENT = 0xFF8B5CF6;
    public static final Logger LOGGER = LoggerFactory.getLogger(NAME);

    private boolean toggleKeyWasDown;

    @Override
    public void onInitializeClient() {
        ModuleManager.init();
        ConfigManager.load();

        ClientTickEvents.END_CLIENT_TICK.register(this::handleMenuKey);
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> ConfigManager.save());

        LOGGER.info("{} {} loaded. Press Right Shift in-game to open the menu.", NAME, VERSION);
    }

    /** Sag Shift tusu: menuyu acar / kapatir. */
    private void handleMenuKey(MinecraftClient client) {
        if (client.getWindow() == null) {
            return;
        }
        boolean down = GLFW.glfwGetKey(client.getWindow().getHandle(), GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
        if (down && !toggleKeyWasDown) {
            if (client.currentScreen instanceof ClickGuiScreen) {
                client.setScreen(null);
            } else if (client.currentScreen == null && client.player != null) {
                client.setScreen(new ClickGuiScreen());
            }
        }
        toggleKeyWasDown = down;
    }
}
