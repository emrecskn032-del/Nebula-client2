package dev.nebula.gui;

import dev.nebula.NebulaClient;
import dev.nebula.config.ConfigManager;
import dev.nebula.module.Category;
import dev.nebula.module.Module;
import dev.nebula.module.ModuleManager;
import dev.nebula.setting.BooleanSetting;
import dev.nebula.setting.ModeSetting;
import dev.nebula.setting.NumberSetting;
import dev.nebula.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.EnumMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Karanlik temali ClickGUI. Fare girdisi GLFW uzerinden okunur; boylece
 * Minecraft surumleri arasindaki Screen girdi API degisikliklerinden etkilenmez.
 * Sol tik: modulu ac/kapat | Sag tik: ayarlari ac/kapat | Baslik: surukle, sag tik daralt.
 */
public class ClickGuiScreen extends Screen {
    private static final int ACCENT = NebulaClient.ACCENT;
    private static final int HEADER_BG = 0xFF1A1A22;
    private static final int ROW_BG = 0xF2141419;
    private static final int ROW_HOVER = 0xFF1E1E29;
    private static final int ROW_ON = 0xFF262042;
    private static final int SETTING_BG = 0xF20D0D12;
    private static final int TEXT = 0xFFE6E6F0;
    private static final int TEXT_DIM = 0xFF8A8AA0;

    private static final int PANEL_W = 126;
    private static final int HEADER_H = 20;
    private static final int ROW_H = 17;
    private static final int SET_H = 15;
    private static final int SLIDER_H = 19;

    private static final class PanelState {
        int x;
        int y;
        boolean open = true;
    }

    // Menu kapanip acilinca konumlar korunsun diye static.
    private static final Map<Category, PanelState> PANELS = new EnumMap<>(Category.class);
    private static final Set<Module> EXPANDED = new HashSet<>();

    private boolean prevLeft;
    private boolean prevRight;
    private PanelState dragPanel;
    private int dragDX;
    private int dragDY;
    private NumberSetting dragSlider;
    private int sliderX;
    private int sliderW;

    public ClickGuiScreen() {
        super(Text.literal(NebulaClient.NAME));
        if (PANELS.isEmpty()) {
            int x = 24;
            for (Category c : Category.values()) {
                PanelState ps = new PanelState();
                ps.x = x;
                ps.y = 34;
                PANELS.put(c, ps);
                x += PANEL_W + 10;
            }
        }
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void removed() {
        super.removed();
        ConfigManager.save();
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        TextRenderer tr = mc.textRenderer;
        long handle = mc.getWindow().getHandle();

        boolean left = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean right = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        boolean leftClick = left && !prevLeft;
        boolean rightClick = right && !prevRight;
        prevLeft = left;
        prevRight = right;

        if (!left) {
            dragPanel = null;
            dragSlider = null;
        }
        if (dragPanel != null) {
            dragPanel.x = mouseX - dragDX;
            dragPanel.y = mouseY - dragDY;
        }
        if (dragSlider != null) {
            updateSlider(mouseX);
        }

        // Arka plan karartma + baslik
        ctx.fill(0, 0, width, height, 0x99000000);
        ctx.drawText(tr, NebulaClient.NAME.toUpperCase() + "  " + NebulaClient.VERSION, 24, 12, ACCENT, true);
        ctx.drawText(tr, "Right Shift: close  |  LMB: toggle  |  RMB: settings", 24, 22, TEXT_DIM, false);

        Module hovered = null;

        for (Category cat : Category.values()) {
            PanelState ps = PANELS.get(cat);
            int x = ps.x;
            int y = ps.y;

            // Baslik
            ctx.fill(x, y, x + PANEL_W, y + HEADER_H, HEADER_BG);
            ctx.fill(x, y + HEADER_H - 1, x + PANEL_W, y + HEADER_H, ACCENT);
            ctx.drawText(tr, cat.getDisplayName(), x + 8, y + 6, TEXT, false);
            String arrow = ps.open ? "-" : "+";
            ctx.drawText(tr, arrow, x + PANEL_W - 12, y + 6, TEXT_DIM, false);

            if (dragPanel == null && dragSlider == null && inside(mouseX, mouseY, x, y, PANEL_W, HEADER_H)) {
                if (leftClick) {
                    dragPanel = ps;
                    dragDX = mouseX - x;
                    dragDY = mouseY - y;
                } else if (rightClick) {
                    ps.open = !ps.open;
                }
            }

            if (!ps.open) {
                continue;
            }

            int cy = y + HEADER_H;
            for (Module m : ModuleManager.byCategory(cat)) {
                boolean hover = inside(mouseX, mouseY, x, cy, PANEL_W, ROW_H);
                int bg = m.isEnabled() ? ROW_ON : (hover ? ROW_HOVER : ROW_BG);
                ctx.fill(x, cy, x + PANEL_W, cy + ROW_H, bg);
                if (m.isEnabled()) {
                    ctx.fill(x, cy, x + 2, cy + ROW_H, ACCENT);
                }
                ctx.drawText(tr, m.getName(), x + 8, cy + 5, m.isEnabled() ? TEXT : TEXT_DIM, false);

                boolean hasSettings = !m.getSettings().isEmpty();
                if (hasSettings) {
                    ctx.drawText(tr, EXPANDED.contains(m) ? "v" : ">", x + PANEL_W - 12, cy + 5, TEXT_DIM, false);
                }

                if (hover) {
                    hovered = m;
                    if (dragPanel == null && dragSlider == null) {
                        if (leftClick) {
                            m.toggle();
                        } else if (rightClick && hasSettings) {
                            if (!EXPANDED.remove(m)) {
                                EXPANDED.add(m);
                            }
                        }
                    }
                }
                cy += ROW_H;

                if (hasSettings && EXPANDED.contains(m)) {
                    for (Setting s : m.getSettings()) {
                        cy += drawSetting(ctx, tr, s, x, cy, mouseX, mouseY, leftClick, rightClick);
                    }
                }
            }
            ctx.fill(x, cy, x + PANEL_W, cy + 2, HEADER_BG);
        }

        if (hovered != null) {
            String desc = hovered.getDescription();
            int w = tr.getWidth(desc);
            int bx = mouseX + 10;
            int by = mouseY + 10;
            ctx.fill(bx - 3, by - 3, bx + w + 3, by + 11, 0xF0101014);
            ctx.fill(bx - 3, by - 3, bx - 1, by + 11, ACCENT);
            ctx.drawText(tr, desc, bx + 2, by, TEXT, false);
        }
    }

    /** Bir ayar satirini cizer ve etkilesimi isler; satirin yuksekligini dondurur. */
    private int drawSetting(DrawContext ctx, TextRenderer tr, Setting s, int x, int y,
                            int mouseX, int mouseY, boolean leftClick, boolean rightClick) {
        if (s instanceof BooleanSetting b) {
            boolean hover = inside(mouseX, mouseY, x, y, PANEL_W, SET_H);
            ctx.fill(x, y, x + PANEL_W, y + SET_H, hover ? ROW_HOVER : SETTING_BG);
            ctx.drawText(tr, b.getName(), x + 12, y + 4, TEXT_DIM, false);
            int bx = x + PANEL_W - 20;
            ctx.fill(bx, y + 3, bx + 10, y + 13, 0xFF2A2A36);
            if (b.get()) {
                ctx.fill(bx + 2, y + 5, bx + 8, y + 11, ACCENT);
            }
            if (hover && leftClick && dragPanel == null && dragSlider == null) {
                b.toggle();
            }
            return SET_H;
        }

        if (s instanceof ModeSetting mode) {
            boolean hover = inside(mouseX, mouseY, x, y, PANEL_W, SET_H);
            ctx.fill(x, y, x + PANEL_W, y + SET_H, hover ? ROW_HOVER : SETTING_BG);
            ctx.drawText(tr, mode.getName() + ": ", x + 12, y + 4, TEXT_DIM, false);
            ctx.drawText(tr, mode.get(), x + 12 + tr.getWidth(mode.getName() + ": "), y + 4, ACCENT, false);
            if (hover && (leftClick || rightClick) && dragPanel == null && dragSlider == null) {
                mode.cycle();
            }
            return SET_H;
        }

        if (s instanceof NumberSetting n) {
            boolean hover = inside(mouseX, mouseY, x, y, PANEL_W, SLIDER_H);
            ctx.fill(x, y, x + PANEL_W, y + SLIDER_H, SETTING_BG);

            String label = n.getName();
            String value = formatNumber(n);
            ctx.drawText(tr, label, x + 12, y + 3, TEXT_DIM, false);
            ctx.drawText(tr, value, x + PANEL_W - 8 - tr.getWidth(value), y + 3, TEXT, false);

            int barX = x + 12;
            int barW = PANEL_W - 24;
            int barY = y + 14;
            ctx.fill(barX, barY, barX + barW, barY + 3, 0xFF2A2A36);
            double pct = (n.get() - n.getMin()) / (n.getMax() - n.getMin());
            int fillW = (int) Math.round(barW * Math.max(0, Math.min(1, pct)));
            ctx.fill(barX, barY, barX + fillW, barY + 3, ACCENT);
            ctx.fill(barX + fillW - 1, barY - 1, barX + fillW + 1, barY + 4, TEXT);

            if (hover && leftClick && dragPanel == null && dragSlider == null) {
                dragSlider = n;
                sliderX = barX;
                sliderW = barW;
                updateSlider(mouseX);
            }
            return SLIDER_H;
        }

        return 0;
    }

    private void updateSlider(int mouseX) {
        if (dragSlider == null) {
            return;
        }
        double pct = (mouseX - sliderX) / (double) sliderW;
        pct = Math.max(0, Math.min(1, pct));
        dragSlider.set(dragSlider.getMin() + pct * (dragSlider.getMax() - dragSlider.getMin()));
    }

    private static String formatNumber(NumberSetting n) {
        double v = n.get();
        return v == Math.floor(v) ? String.valueOf((int) v) : String.format("%.1f", v);
    }

    private static boolean inside(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }
}
