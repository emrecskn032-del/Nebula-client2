package dev.nebula.module.impl;

import dev.nebula.module.Category;
import dev.nebula.module.Module;
import net.minecraft.client.network.ClientPlayerEntity;

public class SprintModule extends Module {
    public SprintModule() {
        super("Sprint", "Ileri giderken otomatik kosar.", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc().player;
        if (p == null) {
            return;
        }
        if (mc().options.forwardKey.isPressed()
                && !p.isSneaking()
                && !p.horizontalCollision
                && p.getHungerManager().getFoodLevel() > 6) {
            p.setSprinting(true);
        }
    }
}
