package dev.nebula.module;

public enum Category {
    MOVEMENT("Movement"),
    RENDER("Render"),
    PLAYER("Player"),
    HUD("HUD");

    private final String displayName;

    Category(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }
}
