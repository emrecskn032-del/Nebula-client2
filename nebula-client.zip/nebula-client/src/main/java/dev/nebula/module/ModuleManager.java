package dev.nebula.module;

import dev.nebula.NebulaClient;
import dev.nebula.module.impl.AntiAfkModule;
import dev.nebula.module.impl.ArrayListModule;
import dev.nebula.module.impl.AutoRespawnModule;
import dev.nebula.module.impl.FlyModule;
import dev.nebula.module.impl.FullbrightModule;
import dev.nebula.module.impl.InfoHudModule;
import dev.nebula.module.impl.SpeedModule;
import dev.nebula.module.impl.SprintModule;
import dev.nebula.module.impl.ZoomModule;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class ModuleManager {
    private static final List<Module> MODULES = new ArrayList<>();

    private ModuleManager() {
    }

    public static void init() {
        // Movement
        register(new SprintModule());
        register(new SpeedModule());
        register(new FlyModule());
        // Render
        register(new FullbrightModule());
        register(new ZoomModule());
        // Player
        register(new AutoRespawnModule());
        register(new AntiAfkModule());
        // HUD
        register(new InfoHudModule());
        register(new ArrayListModule());

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.world == null) {
                return;
            }
            for (Module m : MODULES) {
                if (!m.isEnabled()) {
                    continue;
                }
                try {
                    m.onTick();
                } catch (Exception e) {
                    NebulaClient.LOGGER.error("Module tick failed: {}", m.getName(), e);
                }
            }
        });

        HudElementRegistry.addLast(Identifier.of(NebulaClient.MOD_ID, "overlay"), (context, tickCounter) -> {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.player == null || client.options.hudHidden) {
                return;
            }
            for (Module m : MODULES) {
                if (!m.isEnabled()) {
                    continue;
                }
                try {
                    m.onHudRender(context);
                } catch (Exception e) {
                    NebulaClient.LOGGER.error("Module HUD render failed: {}", m.getName(), e);
                }
            }
        });
    }

    private static void register(Module module) {
        MODULES.add(module);
    }

    public static List<Module> getModules() {
        return Collections.unmodifiableList(MODULES);
    }

    public static List<Module> byCategory(Category category) {
        List<Module> result = new ArrayList<>();
        for (Module m : MODULES) {
            if (m.getCategory() == category) {
                result.add(m);
            }
        }
        return result;
    }
}
