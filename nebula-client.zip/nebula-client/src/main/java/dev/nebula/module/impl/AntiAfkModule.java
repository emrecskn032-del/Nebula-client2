package dev.nebula.module.impl;

import dev.nebula.module.Category;
import dev.nebula.module.Module;
import dev.nebula.setting.NumberSetting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.Hand;

public class AntiAfkModule extends Module {
    private final NumberSetting interval = add(new NumberSetting("Seconds", 30, 5, 120, 5));
    private int ticks;

    public AntiAfkModule() {
        super("AntiAFK", "Belirli araliklarla elini sallar.", Category.PLAYER);
    }

    @Override
    public void onEnable() {
        ticks = 0;
    }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc().player;
        if (p == null) {
            return;
        }
        if (++ticks >= interval.getInt() * 20) {
            ticks = 0;
            p.swingHand(Hand.MAIN_HAND);
        }
    }
}
