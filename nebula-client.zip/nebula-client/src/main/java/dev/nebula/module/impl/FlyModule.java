package dev.nebula.module.impl;

import dev.nebula.module.Category;
import dev.nebula.module.Module;
import dev.nebula.setting.NumberSetting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerAbilities;

public class FlyModule extends Module {
    private final NumberSetting speed = add(new NumberSetting("Speed", 1.0, 0.1, 5.0, 0.1));

    public FlyModule() {
        super("Fly", "Ucma yetenegini acar (tek oyunculu / izinli sunucular).", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc().player;
        if (p == null) {
            return;
        }
        PlayerAbilities a = p.getAbilities();
        a.allowFlying = true;
        a.setFlySpeed(0.05f * speed.getFloat());
    }

    @Override
    public void onDisable() {
        ClientPlayerEntity p = mc().player;
        if (p == null) {
            return;
        }
        PlayerAbilities a = p.getAbilities();
        a.setFlySpeed(0.05f);
        if (!p.isCreative() && !p.isSpectator()) {
            a.allowFlying = false;
            a.flying = false;
        }
    }
}
