package dev.nebula.module.impl;

import dev.nebula.NebulaClient;
import dev.nebula.module.Category;
import dev.nebula.module.Module;
import dev.nebula.module.ModuleManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class ArrayListModule extends Module {
    public ArrayListModule() {
        super("ArrayList", "Acik modulleri sag ustte listeler.", Category.HUD);
        loadEnabled(true);
    }

    @Override
    public void onHudRender(DrawContext ctx) {
        MinecraftClient c = mc();
        TextRenderer tr = c.textRenderer;

        List<Module> active = new ArrayList<>();
        for (Module m : ModuleManager.getModules()) {
            if (m.isEnabled() && m.getCategory() != Category.HUD) {
                active.add(m);
            }
        }
        active.sort(Comparator.comparingInt((Module m) -> tr.getWidth(m.getName())).reversed());

        int screenW = c.getWindow().getScaledWidth();
        int y = 4;
        for (Module m : active) {
            int w = tr.getWidth(m.getName());
            int x = screenW - w - 8;
            ctx.fill(x - 3, y, screenW, y + 11, 0xB0101014);
            ctx.fill(screenW - 2, y, screenW, y + 11, NebulaClient.ACCENT);
            ctx.drawText(tr, m.getName(), x, y + 2, 0xFFE6E6F0, true);
            y += 11;
        }
    }
}
