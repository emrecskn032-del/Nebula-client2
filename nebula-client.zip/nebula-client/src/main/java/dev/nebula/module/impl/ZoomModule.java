package dev.nebula.module.impl;

import dev.nebula.module.Category;
import dev.nebula.module.Module;
import dev.nebula.setting.NumberSetting;

public class ZoomModule extends Module {
    private final NumberSetting fov = add(new NumberSetting("FOV", 30, 30, 70, 1));
    private Integer originalFov;

    public ZoomModule() {
        super("Zoom", "Gorus acisini daraltarak yakinlastirir.", Category.RENDER);
    }

    @Override
    public void onTick() {
        if (originalFov == null) {
            originalFov = mc().options.getFov().getValue();
        }
        mc().options.getFov().setValue(fov.getInt());
    }

    @Override
    public void onDisable() {
        if (originalFov != null) {
            mc().options.getFov().setValue(originalFov);
            originalFov = null;
        }
    }
}
