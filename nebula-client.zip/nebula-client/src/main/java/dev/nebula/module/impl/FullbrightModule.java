package dev.nebula.module.impl;

import dev.nebula.module.Category;
import dev.nebula.module.Module;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;

public class FullbrightModule extends Module {
    public FullbrightModule() {
        super("Fullbright", "Her yeri aydinlik gosterir (istemci tarafli gece gorusu).", Category.RENDER);
    }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc().player;
        if (p == null) {
            return;
        }
        StatusEffectInstance current = p.getStatusEffect(StatusEffects.NIGHT_VISION);
        if (current == null || current.getDuration() < 400) {
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 1000, 0, false, false));
        }
    }

    @Override
    public void onDisable() {
        ClientPlayerEntity p = mc().player;
        if (p != null) {
            p.removeStatusEffect(StatusEffects.NIGHT_VISION);
        }
    }
}
