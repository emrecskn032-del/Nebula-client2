package dev.nebula.module.impl;

import dev.nebula.module.Category;
import dev.nebula.module.Module;
import net.minecraft.client.network.ClientPlayerEntity;

public class AutoRespawnModule extends Module {
    public AutoRespawnModule() {
        super("AutoRespawn", "Oldugunde otomatik yeniden dogar.", Category.PLAYER);
    }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc().player;
        if (p != null && p.isDead()) {
            p.requestRespawn();
        }
    }
}
