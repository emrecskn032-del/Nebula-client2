package dev.nebula.module.impl;

import dev.nebula.NebulaClient;
import dev.nebula.module.Category;
import dev.nebula.module.Module;
import dev.nebula.setting.BooleanSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;

public class InfoHudModule extends Module {
    private final BooleanSetting watermark = add(new BooleanSetting("Watermark", true));
    private final BooleanSetting fps = add(new BooleanSetting("FPS", true));
    private final BooleanSetting coords = add(new BooleanSetting("Coordinates", true));

    public InfoHudModule() {
        super("Info", "Filigran, FPS ve koordinat bilgisini gosterir.", Category.HUD);
        loadEnabled(true);
    }

    @Override
    public void onHudRender(DrawContext ctx) {
        MinecraftClient c = mc();
        TextRenderer tr = c.textRenderer;
        int y = 6;

        if (watermark.get()) {
            String text = NebulaClient.NAME + " " + NebulaClient.VERSION;
            int w = tr.getWidth(text);
            ctx.fill(4, 4, 4 + w + 12, 18, 0xB0101014);
            ctx.fill(4, 4, 6, 18, NebulaClient.ACCENT);
            ctx.drawText(tr, text, 11, 8, 0xFFFFFFFF, true);
            y = 24;
        }
        if (fps.get()) {
            ctx.drawText(tr, c.getCurrentFps() + " FPS", 6, y, 0xFFE6E6F0, true);
            y += 11;
        }
        if (coords.get()) {
            ClientPlayerEntity p = c.player;
            if (p != null) {
                String s = String.format("XYZ: %.1f / %.1f / %.1f", p.getX(), p.getY(), p.getZ());
                ctx.drawText(tr, s, 6, y, 0xFFE6E6F0, true);
            }
        }
    }
}
