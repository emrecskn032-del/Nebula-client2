package dev.nebula.module.impl;

import dev.nebula.module.Category;
import dev.nebula.module.Module;
import dev.nebula.setting.NumberSetting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.GameOptions;
import net.minecraft.util.math.Vec3d;

public class SpeedModule extends Module {
    private final NumberSetting multiplier = add(new NumberSetting("Multiplier", 1.5, 1.0, 3.0, 0.1));

    public SpeedModule() {
        super("Speed", "Yerdeyken yatay hizi artirir.", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc().player;
        if (p == null || !p.isOnGround() || p.isSneaking()) {
            return;
        }
        GameOptions o = mc().options;
        int forward = (o.forwardKey.isPressed() ? 1 : 0) - (o.backKey.isPressed() ? 1 : 0);
        int strafe = (o.leftKey.isPressed() ? 1 : 0) - (o.rightKey.isPressed() ? 1 : 0);
        if (forward == 0 && strafe == 0) {
            return;
        }

        double yaw = Math.toRadians(p.getYaw());
        double dx = -Math.sin(yaw) * forward + Math.cos(yaw) * strafe;
        double dz = Math.cos(yaw) * forward + Math.sin(yaw) * strafe;
        double len = Math.hypot(dx, dz);
        if (len < 1.0E-4) {
            return;
        }

        double speed = 0.2873 * multiplier.get();
        Vec3d v = p.getVelocity();
        p.setVelocity(dx / len * speed, v.y, dz / len * speed);
    }
}
