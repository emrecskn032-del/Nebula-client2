package dev.nebula.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public class ModeSetting extends Setting {
    private final String[] modes;
    private int index;

    public ModeSetting(String name, String defaultMode, String... modes) {
        super(name);
        this.modes = modes;
        for (int i = 0; i < modes.length; i++) {
            if (modes[i].equalsIgnoreCase(defaultMode)) {
                index = i;
            }
        }
    }

    public String get() {
        return modes[index];
    }

    public boolean is(String mode) {
        return modes[index].equalsIgnoreCase(mode);
    }

    public void cycle() {
        index = (index + 1) % modes.length;
    }

    @Override
    public JsonElement toJson() {
        return new JsonPrimitive(get());
    }

    @Override
    public void fromJson(JsonElement element) {
        try {
            if (element != null && element.isJsonPrimitive()) {
                String s = element.getAsString();
                for (int i = 0; i < modes.length; i++) {
                    if (modes[i].equalsIgnoreCase(s)) {
                        index = i;
                        return;
                    }
                }
            }
        } catch (RuntimeException ignored) {
        }
    }
}
