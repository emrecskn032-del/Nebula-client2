package dev.nebula.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.nebula.NebulaClient;
import dev.nebula.module.Module;
import dev.nebula.module.ModuleManager;
import dev.nebula.setting.Setting;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

public final class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private ConfigManager() {
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("nebula.json");
    }

    public static void save() {
        JsonObject root = new JsonObject();
        for (Module m : ModuleManager.getModules()) {
            JsonObject entry = new JsonObject();
            entry.addProperty("enabled", m.isEnabled());
            JsonObject settings = new JsonObject();
            for (Setting s : m.getSettings()) {
                settings.add(s.getName(), s.toJson());
            }
            entry.add("settings", settings);
            root.add(m.getName(), entry);
        }
        try {
            Files.writeString(file(), GSON.toJson(root), StandardCharsets.UTF_8);
        } catch (IOException e) {
            NebulaClient.LOGGER.error("Could not save config", e);
        }
    }

    public static void load() {
        Path path = file();
        if (!Files.exists(path)) {
            return;
        }
        try {
            JsonObject root = JsonParser.parseString(Files.readString(path, StandardCharsets.UTF_8)).getAsJsonObject();
            for (Module m : ModuleManager.getModules()) {
                JsonElement e = root.get(m.getName());
                if (e == null || !e.isJsonObject()) {
                    continue;
                }
                JsonObject entry = e.getAsJsonObject();
                if (entry.has("enabled")) {
                    m.loadEnabled(entry.get("enabled").getAsBoolean());
                }
                if (entry.has("settings") && entry.get("settings").isJsonObject()) {
                    JsonObject settings = entry.getAsJsonObject("settings");
                    for (Setting s : m.getSettings()) {
                        s.fromJson(settings.get(s.getName()));
                    }
                }
            }
        } catch (IOException | RuntimeException e) {
            NebulaClient.LOGGER.error("Could not load config", e);
        }
    }
}
